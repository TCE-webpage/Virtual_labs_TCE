function activeOn(){
    document.getElementsByClassName("active")[0].style.border="solid 2px thistle";
}
$(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })